<?php
	return array(
		'modules'=>'file',
		'templates/admin'=>'file'
	);
?>
