<?php
	return array(	'title'=>'Fichiers',
			'description'=>'Chargez des fichiers sur votre site, afin de pouvoir les inclure dans vos pages ou les télécharger plus tard.',
			'link'=>'?module=file&action=index'
	);
?>
