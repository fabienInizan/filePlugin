<?php
	return array(
		'id'=>'file',
		'title'=>'Fichiers',
		'description'=>'Chargez des fichiers sur votre site, afin de pouvoir les inclure dans vos pages ou les télécharger plus tard.',
		'version'=>'1.0',
		'date'=>'2012-11-25'
	);
?>
